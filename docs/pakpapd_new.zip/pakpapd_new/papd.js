$(window).on('beforeunload', function() {
    $(window).scrollTop(0);
});
// function myFunction() {
//   var element = document.getElementById("newid");
//   element.classList.add("eventtext1");
// }
 // document.getElementById('button1').addEventListener('click',function new(){
 //   document.getElementById('newid').classList.add('eventtext1');
 // });


 // const updiv=document.querySelector("btn");
 // add.addEventListener("click",(){
 //   updiv.addClassList.remove("eventtext1")
 // })
